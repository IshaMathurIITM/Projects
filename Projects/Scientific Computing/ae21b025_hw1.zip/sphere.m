  phiv=linspace(0,pi,30);
  thetav=linspace(0,2*pi,30);
  [phi,theta]=meshgrid(phiv,thetav);
  x=2*sin(phi).*cos(theta);
  y=2*sin(phi).*sin(theta);
  z=2*cos(phi);
  mesh(x,y,z)
  axis equal
  view(135,30)
  box on
  xlabel('x-axis')
  ylabel('y-axis')
  zlabel('z-axis')
