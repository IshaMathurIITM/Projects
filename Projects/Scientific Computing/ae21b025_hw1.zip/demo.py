import numpy
import math
import matplotlib
import matplotlib.pyplot as plt
theta= numpy.linspace(0,2*math.pi,72)
                         
sin_func = numpy.zeros([72,1])

for j in range(72):
     sin_func[j] = math.sin(theta[j])
fig,ax=plt.subplots()
plt.plot(theta/math.pi*180,sin_func,'o-',label='sine')

plt.xlabel('Angles, degree')
plt.ylabel('f(x)')
plt.xticks(numpy.linspace(0,360,9))
plt.show()