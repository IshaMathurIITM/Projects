import matplotlib.pyplot as plt
from scipy.integrate import quad
from scipy.special import roots_legendre
import math

def func(x):
    y = (math.exp(-x))*math.pow(math.sin(4*x),2)
    return y
correct_integral = quad(func, -1, 1)[0]

n = int(input("Enter the number of terms : "))

roots, weights = roots_legendre(n)
log_error = list()
for j in range(1, n + 1):
    calc_integral = 0
    for i in range(1, j + 1):
        calc_integral += func(roots[i-1])*weights[i-1]
    log_error.append(math.log(abs(correct_integral - calc_integral)))
x_list = list()
for j in range(1, n + 1):
    x_list.append(j)

plt.plot(x_list, log_error,label='log(error) v/s N')
plt.title('Log(error) v/s (N)')
plt.xlabel('N')
plt.ylabel('Log (error)')
plt.legend()
plt.show()
