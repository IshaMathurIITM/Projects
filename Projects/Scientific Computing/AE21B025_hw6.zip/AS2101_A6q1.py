# Legendre polynomial
def P(n, x): 
    if(n == 0):
        return 1 # P0 = 1
    elif(n == 1):
        return x # P1 = x
    else:
        return (((2 * n)-1)*x * P(n-1, x)-(n-1)*P(n-2, x))/float(n)

n = 3
X = 5
print("The value of the polynomial at given point is:", P(n, X))
import matplotlib 
import matplotlib.pyplot as plt
import numpy as np
  
# Creating an array of x values
x = np.linspace(-1, 1, 200) 
  
# for which polynomial values are evaluated and plotted
for i in range(1, 6):
  
    # Labelling according to order
    plt.plot(x, P(i, x), label ="P"+str(i)) 
  
plt.legend(loc ="best")
plt.xlabel("X")
plt.ylabel("Pn")
plt.show()
