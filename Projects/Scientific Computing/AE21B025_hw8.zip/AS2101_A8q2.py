import matplotlib.pyplot as plt
import numpy as np
from scipy.signal import find_peaks
from scipy.fft import fft, fftfreq

file_path = r"C:\Users\Lenovo\Downloads\signal.inp"
file = np.loadtxt(file_path, delimiter = ' ', dtype = 'float')

t = list()
signal = list()

for n in range(len(file)):
    # Extracting time values
    x = file[n,0]
    t.append(x)
    # Extracting signal values
    y = file[n,1]
    signal.append(y)

yf = np.abs(fft(signal))/1000
# xf = fftfreq(Number of Samples, ((time[999] - time[0])/(Number of Samples)))
xf = fftfreq(1000, 0.0001)

rfreq = list()

for n in range(0, 999):
    if yf[n] > 0.15 and xf[n] > 0 :
        rfreq.append(xf[n])

print("The magnitude of frequencies : ")
for n in rfreq:
    print("\t", n)
