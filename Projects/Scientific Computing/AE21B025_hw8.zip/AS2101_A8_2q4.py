import matplotlib.pyplot as plt
import numpy as np
import statistics as st
from scipy.signal import find_peaks
from scipy.fft import fft, fftfreq, ifft

file_path = r"C:\Users\Lenovo\Downloads\noise.inp"
file = np.loadtxt(file_path, delimiter = ' ', dtype = 'float')

t = list()
signal = list()

for n in range(len(file)):
    # Taking time values
    x = file[n,0]
    t.append(x)
    # Taking signal values
    y = file[n,1]
    signal.append(y)

new_signal = list()

for n in range(0,996):
    new_signal.append(st.median((signal[n : (n + 4)])))

new_yf = fft(new_signal)
new_xf = fftfreq(996, 0.0001)

plt.plot(new_xf, np.abs(new_yf), linewidth = 0.5)
plt.title('FFT of the average time-signal')
plt.xlabel('f')
plt.ylabel('FFT')
plt.grid()
plt.legend(loc = 'upper right')
plt.show()
