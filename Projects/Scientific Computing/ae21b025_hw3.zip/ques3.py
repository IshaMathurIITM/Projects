import math
import numpy as np
import matplotlib
import matplotlib.pyplot as plt

def f1(x):
    return x**3-3*x**2-x+9 
    


def f2(x):
    return (math.exp(x))*(f1(x))
    

def f3(x):
    return x**3-2*x+2

    
def dxf1(x):
    return 3*x**2-6*x-1

def dxf2(x):
    return (math.exp(x))*(x**3-7*x+8)

t=float(input("enter tolerance value :"))

def bisection_method_f1(a,b,t):
    y=[]
    
    i=True
    j=1
    x=[]
    while i:
        c=(a+b)/2
        print("Iteration number ",j,"\n")
           
    
        if f1(c)*f1(b)<0:
            a=c

        else:
            b=c

        y.append(f1(c))
        
        print
        i=abs(f1(c))>t

        print(i)
        x.append(j)
        j+=1
       
    plt.plot(x,y)
    
    return c

def newton_method_f1(x4,t):
    y=[]
    x=[]

    i=True
    j=1

    while i:
        if dxf1(x4)==0:
            print("denominator zero!!!")
            break

        x1=x4-f1(x4)/dxf1(x4)
        print("iteration number: ",j)
        
        
        y.append(f1(x4))
        x.append(j)
        j+=1
        x4=x1
        print(x1,f1(x1))
        i=abs(f1(x1))>t
        print(i)
    plt.plot(x,y)
    
    return x1
def secant_method_f1(x0,x1,t):
    y=[]
    x=[]

    
    i=True
    j=1

    while i:
        if f1(x0)==f1(x1):
            print("division by zero error!!!")
            break
        
        print("Iteration number ",j)

        m=(f1(x1)-f1(x0))/(x1-x0)
        print(m)
        if m==0:
            print("division by zero error!!!")
            break

        x2=x0-(f1(x0)/m)
        print(x2)

        y.append(f1(x0))
        x.append(j)
        plt.plot(x,y)
        
        
        

        x0=x1
        x1=x2

        i=abs(f1(x2))>t
        j+=1
        

    if m!=0:
        return x2

def bisection_method_f2(a,b,t):
    y=[]
    
    i=True
    j=1
    x=[]
    while i:
        c=(a+b)/2
        print("Iteration number ",j,"\n")
           
    
        if f2(c)*f2(b)<0:
            a=c

        else:
            b=c

        y.append(f2(c))
        
        print
        i=abs(f2(c))>t
        x.append(j)
        j+=1
       
    plt.plot(x,y)
    
    
    return c



def newton_method_f2(x3,t):
    y=[]
    x=[]

    i=True
    j=1

    while i:
        if dxf2(x3)==0:
            print("denominator zero!!!")
            break

        x1=x3-f2(x3)/dxf2(x3)
        print("iteration number: ",j)
        
        
        y.append(f2(x3))
        x.append(j)
        j+=1
        x3=x1
        print(x1,f2(x1))
        i=abs(f2(x1))>t
        print(i)
    plt.plot(x,y)
    
    return x1

def secant_method_f2(x0,x1,t):
    y=[]
    x=[]

    
    i=True
    j=1

    while i:
        if f2(x0)==f2(x1):
            print("division by zero error!!!")
            break
        
        print("Iteration number ",j)

        m=(f2(x1)-f2(x0))/(x1-x0)
        print(m)
        if m==0:
            print("division by zero error!!!")
            break

        x2=x0-(f2(x0)/m)
        print(x2)

        y.append(f2(x0))
        x.append(j)
        plt.plot(x,y)
        

        x0=x1
        x1=x2

        i=abs(f2(x2))>t
        j+=1
        

    if m!=0:
        return x2

print("pick your choice \n 1.f1(x)\n 2.f2(x)")
choice=int(input("enter your choice"))


if choice==1:
    a=float(input("enter value of a for bisection method :"))
    b=float(input("enter value of b for bisection method :"))
    x4=float(input("enter initial guess for newton's method :"))
    x0=float(input("enter initial guess for secant method :"))
    x1=float(input("enter second guess for secant method :"))
    bisection_method_f1(a,b,t)
    newton_method_f1(x4,t)
    secant_method_f1(x0,x1,t)
    plt.legend(['bisection method','newton method','secant method'])
    plt.xlabel("no.of iterations")
    plt.ylabel("f1(x)")
    plt.show()

if choice==2:
    a=float(input("enter value of a for bisection method :"))
    b=float(input("enter value of b for bisection method :"))
    x3=float(input("enter initial guess for newton's method :"))
    x0=float(input("enter initial guess for secant method :"))
    x1=float(input("enter second guess for secant method :"))
    bisection_method_f2(a,b,t)
    newton_method_f2(x3,t)
    secant_method_f2(x0,x1,t)
    plt.legend(['bisection method','newton method','secant method'])
    plt.xlabel("no.of iterations")
    plt.ylabel("f2(x)")
    plt.show()
