import math    

def f3(x):
    return x**3-2*x+2

def dervf3(x):
    return 3*x**2-2

t=float(input("enter the tolerance value: "))

#from sympy import *

#x=symbols('x')

#dxf3=diff(f3(x),x)
          
x0=float(input("enter your starting guess :"))

def newton_method_f3(x0,t):

    i=True
    j=1

    while i:
        if dervf3(x0)==0:
            print("denominator zero!!!")
            break

        x1=x0-f3(x0)/dervf3(x0)
        print("iteration number: ",j)
        x0=x1
        j+=1
        print("the x intercept of the tangent at x0=",x1)
        

        i=abs(f3(x1))>t
    return x1
    
print(newton_method_f3(x0,t))
