import math
import numpy as np
import matplotlib
import matplotlib.pyplot as plt

def f1(x):
    return x**3-3*x**2-x+9 
    


def f2(x):
    return (math.exp(x))*(f1(x))
    

def f3(x):
    return x**3-2*x+2
 
e=float(input("enter error value :"))


def bisection_method_f1(a,b,e):
    y=[]
    
    i=True
    j=1
    x=[]
    while i:
        c=(a+b)/2
        print("Iteration number ",j,"\n")
           
    
        if f1(c)*f1(b)<0:
            a=c

        else:
            b=c

        y.append(f1(c))
        
        print(y)
        i=abs(f1(c))>e

       
        x.append(j)
        j+=1
       
    plt.plot(x,y)
    plt.legend(['set 1','set 2'])
    plt.xlabel("iterations")
    plt.ylabel("f1(x)")
    return c

for i in range(2):

    a=float(input("enter value of a :"))
    b=float(input("enter value of b :"))
    print("the root is ",bisection_method_f1(a,b,e),"\n")
plt.show()
