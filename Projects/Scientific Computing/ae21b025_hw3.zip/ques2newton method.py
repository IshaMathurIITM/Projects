import math
import matplotlib
import matplotlib.pyplot as plt

def f1(x):
    return x**3-3*x**2-x+9

def dervf1(x):
    return 3*x**2-6*x-1

def f2(x):
    return (math.exp(x))*(x**3-3*x**2-x+9)

def dervf2(x):
    return (math.exp(x))*(x**3-7*x+8)


def f3(x):
    return x**3-2*x+2

def dervf3(x):
    return 3*x**2-2

t=float(input("enter the tolerance value: "))
          


def newton_f1(x0,t):

    condition=True
    j=1
    x=[]
    y=[]

    while condition:
        if dervf1(x0)==0:
            print("denominator zero!!!")
            break

        x1=x0-f1(x0)/dervf1(x0)
        
        
        
        
        y.append(f1(x0))
        x.append(j)
        j+=1
        x0=x1

        condition=abs(f1(x1))>t
    plt.plot(x,y)
    return x1
    
for i in range(2):
    x0=float(input("enter initial guess"))
    print("the root is ",newton_f1(x0,t))
plt.show()
    
