import math
import matplotlib
import matplotlib.pyplot as plt

def f2(x):
    return (math.exp(x))(x**3-3*x**2-x+9)

def dervf1(x):
    return 3*x**2-6*x-1

def f2(x):
    return (math.exp(x))*(x**3-3*x**2-x+9)

def dervf2(x):
    return (math.exp(x))*(x**3-7*x+8)


def f3(x):
    return x**3-2*x+2

def dervf2(x):
    return 3*x**2-2

t=float(input("enter the tolerance value: "))
          


def newton_f2(x0,t):

    condition=True
    j=1
    x=[]
    y=[]

    while condition:
        if dervf2(x0)==0:
            print("denominator zero!!!")
            break

        x1=x0-f2(x0)/dervf2(x0)        
        y.append(f2(x1))
        x.append(j)
        j+=1
        x0=x1
        condition=abs(f2(x1))>t
    plt.plot(x,y)
    return x1
    
for i in range(2):
    x0=float(input("enter initial guess"))
    print("the root is ",newton_f2(x0,t))
plt.xlabel("Number of Iterations")
plt.ylabel("f2(x)")
plt.show()
    
