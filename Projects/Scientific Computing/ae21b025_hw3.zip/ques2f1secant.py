import math
import numpy as np
import matplotlib
import matplotlib.pyplot as plt

def f1(x):
    return (math.exp(x))*(x**3-3*x**2-x+9 )
    


def f2(x):
    return (math.exp(x))*(f1(x))
    

def f3(x):
    return x**3-2*x+2
 


t=float(input("enter tolerance"))


def secant_method_f2(x0,x1,t):
    y=[]
    x=[]

    
    i=True
    j=1

    while i:
        if f2(x0)==f2(x1):
            print("division by zero error!!!")
            break
        
        print("Iteration number ",j)

        m=(f2(x1)-f2(x0))/(x1-x0)
        print(m)
        if m==0:
            print("division by zero error!!!")
            break

        x2=x0-(f2(x0)/m)
        print(x2)

        y.append(f2(x0))
        x.append(j)
        plt.plot(x,y)
        plt.legend(['set 1','set 2'])
        plt.xlabel("no. of iterations")
        plt.ylabel("f2(x)")

        x0=x1
        x1=x2

        i=abs(f2(x2))>t
        j+=1
        

    if m!=0:
        return x2
    


for i in range(2):
    
    x0=float(input("enter first guess"))
    x1=float(input("enter second guess"))
    print("the root  is",secant_method_f2(x0,x1,t))
    
plt.show()
