clear all
a = 0; %interval right
b = pi/2; %interval left
N = 100;
%dx=(b-a)/N;
I=zeros(N,4);

for i=1:N %i is number of sections the interval is divided in
  dx = (b-a)/i;
  i_dx =zeros(1,4);
  for n = 1:i
    x_1 = [sin(n*dx)*dx]
    x_2 = [sin((n+1)*dx)*dx]
    x_3 = [sin((2*n+1)/2*dx)*dx]
    x_4 = [1/2*((sin(n*dx)*dx)+(sin((n+1)*dx)*dx))];
    i_dx_1 = i_dx + x_1;
    i_dx_2 = i_dx + x_2;
    i_dx_3 = i_dx + x_3;
    i_dx_4 = i_dx + x_4;
  endfor
x_1 = linspace(0,N);
x_2 = linspace(0,N);
x_3 = linspace(0,N);
x_4 = linspace(0,N);
Error = I - ones(size(I));
i = 1:100;
x_1 = dx;
x_2 = dx;
x_3 = dx;
x_4 = dx;
y_1 = Error(:,1);
y_2 = Error(:,2);
y_3 = Error(:,3);
y_4 = Error(:,4);
x2_1 = x_1.^2;
x2_2 = x_2.^2;
x2_3 = x_3.^2;
x2_4 = x_4.^2;
xy_1 = x.*y_1;
xy_2 = x.*y_2;
xy_3 = x.*y_3;
xy_4 = x.*y_4;
n = length(x);
for j=1:4;
  a_1(j) = (sum(y_1)*sum(x2(j))-sum(x)*sum(xy_1))/(n*sum(x2)-(sum(x))^2);
  a_2(j) = (sum(y_2)*sum(x2(j))-sum(x)*sum(xy_2))/(n*sum(x2)-(sum(x))^2);
  a_3(j) = (sum(y_3)*sum(x2(j))-sum(x)*sum(xy_3))/(n*sum(x2)-(sum(x))^2);
  a_4(j) = (sum(y_4)*sum(x2(j))-sum(x)*sum(xy_4))/(n*sum(x2)-(sum(x))^2);
  b_1(j) = (n*sum(xy_1)-sum(x(j))*sum(y_1))/(n*sum(x2) - (sum(x))^2);
  b_2(j) = (n*sum(xy_2)-sum(x(j))*sum(y_2))/(n*sum(x2) - (sum(x))^2);
  b_3(j) = (n*sum(xy_3)-sum(x(j))*sum(y_3))/(n*sum(x2) - (sum(x))^2);
  b_4(j) = (n*sum(xy_4)-sum(x(j))*sum(y_4))/(n*sum(x2) - (sum(x))^2);
  xq = linspace(min(x(j)),max(x(j)),1000);
endfor

figure
grid on
plot(xq,a_1+b_1*xq,'r-.');
hold on
plot(xq,a_2+b_2*xq,'r-.');
hold on
plot(xq,a_3+b_3*xq,'r-.');
hold on
plot(xq,a_4+b_4*xq,'r-.');
legend({"left", "right", "midpoint", "trapezoid"})
xlabel("dx")
ylabel("Error")
