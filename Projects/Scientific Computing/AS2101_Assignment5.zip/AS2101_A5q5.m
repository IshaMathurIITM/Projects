tStart = tic;           % pair 2: tic
a = 0; %interval right
b = pi/2; %interval left
T = zeros(1,100);
   for i=1:100 %i is number of sections the interval is divided in
  dx = (b-a)/i;
  i_dx =zeros(1,4);
  for n = 1:100
    tic();        % pair 1: tic
    x_1 = [sin(n*dx)*dx]
    x_2 = [sin((n+1)*dx)*dx]
    x_3 = [sin((2*n+1)/2*dx)*dx]
    x_4 = [1/2*((sin(n*dx)*dx)+(sin((n+1)*dx)*dx))];
    i_dx_1 = i_dx + x_1;
    i_dx_2 = i_dx + x_2;
    i_dx_3 = i_dx + x_3;
    i_dx_4 = i_dx + x_4;
  endfor
  I_1(i,:) = i_dx_1;
  I_2(i,:) = i_dx_2;
  I_3(i,:) = i_dx_3;
  I_4(i,:) = i_dx_4;
  T_1(i)= toc();  % pair 1: toc
  T_2(i)= toc();
  T_3(i)= toc();
  T_4(i)= toc();
endfor
i=1:100
figure
grid on
plot(i,T_1)
hold on
plot(i,T_2)
hold on
plot(i,T_3)
hold on
plot(i,T_4)
legend({"left", "right", "midpoint", "trapezoid"})
xlabel("x")
ylabel("Computational cost")
