clear all
a = 0; %interval right
b = pi/2; %interval left
N = 100;
%dx=(b-a)/N;
I=zeros(N,2);

for i=1:N %i is number of sections the interval is divided in
  dx = (b-a)/i;
  i_dx =zeros(1,2);
  for n = 1:i
    x = [sin(n*dx)*dx , sin((n+1)*dx)*dx];
    i_dx = i_dx + x;
  endfor
  I(i,:) = i_dx;
endfor

x = linspace(0,N);
figure
grid on
plot(x,I(:,1))
hold on
plot(x,I(:,2))
legend({"left", "right",})
xlabel("x")
ylabel("I")
