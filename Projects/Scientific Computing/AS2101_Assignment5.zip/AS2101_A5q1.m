clear all
a = 0; %interval right
b = pi/2; %interval left
N = 100;
%dx=(b-a)/N;
I=zeros(N,4);

for i=1:N %i is number of sections the interval is divided in
  dx = (b-a)/i;
  i_dx =zeros(1,4);
  for n = 1:i
    x = [sin(n*dx)*dx , sin((n+1)*dx)*dx , sin((2*n+1)/2*dx)*dx, 1/2*((sin(n*dx)*dx)+(sin((n+1)*dx)*dx))];
    i_dx = i_dx + x;
  endfor
  I(i,:) = i_dx;
endfor

x = linspace(0,N);
Error = I - ones(size(I));
figure
grid on
plot(x,Error(:,1))
hold on
plot(x,Error(:,2))
plot(x,Error(:,3))
plot(x,Error(:,4))
legend({"left", "right", "midpoint", "trapezoid"})
xlabel("x")
ylabel("Error")
figure
grid on
plot(log(x),log(Error(:,1)))
hold on
plot(log(x),log(Error(:,2)))
plot(log(x),log(Error(:,3)))
plot(log(x),log(Error(:,4)))
legend({"left", "right", "midpoint", "trapezoid"})
xlabel("log x")
ylabel("log(Error)")

