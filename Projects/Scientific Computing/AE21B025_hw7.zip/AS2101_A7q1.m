clc
clear all
format longG

A = input('Enter the Square Matrix : A = ') %A is the square matrix
b = input('Enter the Vector : b = ') %b is a vector

n = size(A,1); %n is the size of square matrix A
Q = zeros(n,n); %Q ia a orthogonal matrix
R = zeros(n,n); % R is a upper triangular matrix
q = zeros(n,1);
k = zeros(n,1);

for j = 1:n
  k = A(:,j);
  for i = 1:j-1
    q = Q(:,i);
    R(i,j) = dot(q,k);
    k = k - R(i,j) * q;
  end
  no = norm(k);
  Q(:,j) = v/no;
  R(j,j) = no;
end

Q
R

b = b';
y = Q'*b;
x = zeros(n,1);

for j = n:-1:1
    if (R(j,j) == 0)
      error('Matrix is singular!');
    end
    x(j) = y(j)/R(j,j);
    y(1:j-1) = y(1:j-1)-R(1:j-1,j)*x(j);
end
