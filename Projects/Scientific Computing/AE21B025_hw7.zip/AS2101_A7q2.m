clc
clear all
format longG

norm_inf = zeros(1000,1);

for num = 1:1000
  A = rand([-1000,1000],num,num);
  b = rand([-1000,1000],num,1);

  while det(A) == 0
    A = rand([-1000,1000],num,num);
  endwhile

  Q = zeros(num,num);
  R = zeros(num,num);
  q = zeros(num,1);
  k = zeros(num,1);

  for j = 1:num
    k = A(:,j);
    for i = 1:j-1
      q = Q(:,i);
      R(i,j) = dot(q,k);
      v = v - R(i,j) * q;
    end
    no = norm(k);
    Q(:,j) = k/no;
    R(j,j) = no;
  end

  y = Q'*b;
  x = zeros(num,1);

  for j = num:-1:1
      if (R(j,j) == 0)
        error('Matrix is singular!');
      end
      x(j) = y(j)/R(j,j);
      y(1:j-1) = y(1:j-1)-R(1:j-1,j)*x(j);
  end

  Y = A\b;
  error = zeros(num,1);

  for p = 1:num
    error(p) = abs(x(p)-Y(p));
  endfor

  norm_inf(num) = norm(error,inf);
endfor

x = [1:1000];
hold
plot(x,norm_inf)
xlabel('n')  %n is the size of matrix
ylabel('L_\infty error')
title('Plot of L∞ error v/s Matrix size')
legend('L∞ error in x v/s Matrix size')
